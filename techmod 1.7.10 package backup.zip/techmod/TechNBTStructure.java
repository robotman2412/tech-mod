package com.robotman2412.techmod;

public class TechNBTStructure {
	
	public static int STR_carry = 0;
	public static int STR_insert = 1;
	public static int STR_contact = 2;
	
}
